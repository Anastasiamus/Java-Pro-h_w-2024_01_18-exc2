package NewAnimal;

public class Bird extends Animal {
    public Bird(String name, Integer age, Integer weight) {
        super(name, age, weight);
    }
    public void fly(){
        System.out.println(getName() + " fly");
    }
    public void tweet(){
        System.out.println(getName() + "tweet");
    }

    @Override
    public void eat() {
        super.eat();
    }

    @Override
    public void sleep() {
        super.sleep();
    }

    @Override
    public void awake() {
        super.awake();
    }
}

