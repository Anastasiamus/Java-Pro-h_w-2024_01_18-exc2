package NewAnimal;

public class TypeOfFish extends Fish{
    public TypeOfFish(String name, Integer age, Integer weight) {
        super(name, age, weight);
    }
    


}
