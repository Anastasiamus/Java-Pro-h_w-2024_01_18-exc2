package NewAnimal;

public class Main {
    public static void main(String[] args) {
       Fish fish = new Fish ("Olga", 12,23);
        System.out.println(fish.getName() + " " + fish.getAge());
        fish.awake();

        Bird bird = new Bird ( "Anna" , 12,23);
        System.out.println(bird.getAge() + " " + bird.getWeight());
        bird.awake();

        TypeOfFish homeFish = new TypeOfFish("Vobla",12,23);
        System.out.println(homeFish.getName() + " " + fish.getWeight()+ " " + homeFish.getAge());

        homeFish.awake();
        homeFish.laysEggs();

        TypeOfBird smallBird = new TypeOfBird("Kolibri", 12,2);
        System.out.println(smallBird.getName() + " " + smallBird.getAge() + " " + smallBird.getWeight());

        smallBird.fly();
        smallBird.awake();

        smallBird.setName("kesha");
     System.out.println(smallBird.getName());

    }
}


/*2. Создать классы и схему наследования для задачи учета животных в зоопарке:
Как минимум должен быть общий класс Animal с характеристиками и поведением,
 характерными для всех животных.
 А дальше уже Ваше творчество, в котором вы должны разбить животных на группы
  и подгруппы.*/