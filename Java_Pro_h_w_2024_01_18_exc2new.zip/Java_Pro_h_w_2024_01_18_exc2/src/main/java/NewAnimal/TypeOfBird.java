package NewAnimal;

public class TypeOfBird extends Bird{
    public TypeOfBird(String name, Integer age, Integer weight) {
        super(name, age, weight);
    }

}
