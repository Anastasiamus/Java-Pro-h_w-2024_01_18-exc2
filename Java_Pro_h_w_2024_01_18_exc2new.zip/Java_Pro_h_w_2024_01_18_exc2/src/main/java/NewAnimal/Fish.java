package NewAnimal;

public class Fish extends Animal {
    public Fish(String name, Integer age, Integer weight) {
        super(name, age, weight);
    }

    public void swim()
    {
        System.out.println(getName() + " swim");
    }

    public void laysEggs() {
        System.out.println(getName()+ " laysEggs");
    }

    @Override
    public void eat() {
        super.eat();
    }

    @Override
    public void sleep() {
        super.sleep();
    }

    @Override
    public void awake() {
        super.awake();
    }
}


/*2. Создать классы и схему наследования для задачи учета животных в зоопарке:
Как минимум должен быть общий класс Animal с характеристиками и поведением,
 характерными для всех животных.
 А дальше уже Ваше творчество, в котором вы должны разбить животных на группы
  и подгруппы.*/